#! /bin/sh

cmake -S . -B build

