#! /bin/sh

./configure.sh ; ./build.sh && ./build/GAME
