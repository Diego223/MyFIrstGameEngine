#! /bin/sh

rm -rf build
